# rust

This plugin adds completion for [`rustc`](https://doc.rust-lang.org/rustc/index.html), the compiler for the Rust programming language.

To use it, add `rust` to the plugins array in your zshrc file:

```zsh
plugins=(... rust)
```
