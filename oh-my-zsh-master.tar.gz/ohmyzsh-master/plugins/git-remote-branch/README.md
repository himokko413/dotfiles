# git-remote-branch plugin

This plugin adds completion for [`grb`](https://github.com/webmat/git_remote_branch),
or `git_remote_branch`.

To use it, add `git-remote-branch` to the plugins array of your zshrc file:

```zsh
plugins=(... git-remote-branch)
```

## Deprecation

[git_remote_branch was archived in 2018](https://github.com/webmat/git_remote_branch#archived),
meaning it's not actively maintained anymore. Use at your own risk.
