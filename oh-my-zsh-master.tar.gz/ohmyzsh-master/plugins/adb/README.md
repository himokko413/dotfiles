# adb autocomplete plugin

* Adds autocomplete options for all adb commands.
* Add autocomplete for `adb -s`

## Requirements

In order to make this work, you will need to have the Android adb tools set up in your path.
